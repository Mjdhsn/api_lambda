# FOR STATE LEVEL
conditions_country_country = {

    "country": {

        "values": {

            "collation_status": f"""{pu_query['query']}  select (case when status='collated' then 'collated'  when status='non collated' then 'non coalated' when status='canceled' then 'canceled' else 'check manually' end ) AS collation_status from country_result_table  """,
            "over_voting_status": f"""{pu_query['query']} select (case when over_vote_values >0 then remarks else 'NO Over Voting!!' end) as  over_voting_status FROM ct   """,
            "total_over_vote_figure": f"""{pu_query['query']}  select  over_vote_values as Total_over_vote_figures FROM ct	 """,
            "total_registered_votes": f"""{pu_query['query']} SELECT Total_Registered_voters  FROM ct  """,
            "total_accredited_votes": f"""{pu_query['query']}  SELECT Total_Accredited_voters  FROM ct  """,
            "total_rejected_votes": f"""{pu_query['query']} select Total_Rejected_votes   FROM ct """,
            "total_valid_votes": f"""{pu_query['query']}  SELECT total_valid_votes  FROM ct  """,
            "total_votes_casted": f"""{pu_query['query']} SELECT total_vote_casted  FROM ct """,
            "percentage_voters_turnout": f"""{pu_query['query']}  SELECT percentage_voters_turnout  FROM ct  """,
            "general_party_performance": f"""{pu_query['query']}

           select IFF (row_num<2 and total_valid_votes>0 and remarks='OK' AND party='NNPP','clear leading',
 			IFF(row_num<2 and total_valid_votes>0 and over_vote_values>0 AND party='NNPP','leading with doubt',
 			IFF( row_num>1  and total_valid_votes>0 and over_vote_values>0 AND party='NNPP','lagging with doubt',
 			IFF(row_num>1 and total_valid_votes>0 and remarks='OK' AND party='NNPP','clear lagging',''))) )
 			as current_update from win_country
 			order by current_update desc limit 1 ; """

        },

        "tables": {

        "general_party_performance": f"""{pu_query['query']}
    	SELECT ROW_NUMBER() OVER(PARTITION BY country_name ORDER BY votes DESC) AS row_num,party,votes as Scores,		-- 11
        iff(total_vote_casted>0, concat(round(votes/total_vote_casted*100,2),'%'),'Voting in progress...') as percentage_score FROM win_country 
 		 """

        }
    },

}
