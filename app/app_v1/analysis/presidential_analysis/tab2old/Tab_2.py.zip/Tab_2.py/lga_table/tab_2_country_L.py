# FOR LGA LEVEL
conditions_country_lga = {

    "lga": {

        "values": {

            "total": f"""{pu_query['query']}  select  count(*) as count1 from lga_result_table """,
            "total_collated": f"""{pu_query['query']} select COALESCE(sum(case when status = 'collated' OR status='canceled' then 1 else  0 end) ,0) as count1  FROM lgat """,
            "total_non_collated": f"""{pu_query['query']}  select COALESCE(sum(case when status = 'non collated'  then 1 else  0 end) ,0) as count1  FROM lgat """,
            "total_canceled": f"""{pu_query['query']}  select COALESCE(sum(case when status = 'canceled'  then 1 else  0 end) ,0) as count1  FROM lgat """,
            "total_over_voting": f"""{pu_query['query']}  select count(*) as count1 FROM lgat where 1=1 and over_vote_values>0 """,

            "number_clear_win": f"""{pu_query['query']}   select count(*) as count1 FROM win_lga where 1=1 and row_num<2 and total_valid_votes>0 and remarks='OK' AND party='{party_name}' """,
            "number_win_with_doubt": f"""{pu_query['query']}  select count(*) as count1 FROM win_lga where 1=1 and row_num<2 and total_valid_votes>0 and over_vote_values>0 AND party='{party_name}' """,
            "number_of_clear_loss": f"""{pu_query['query']}  select count(*) as count1 FROM win_lga where 1=1 and row_num>1 AND total_valid_votes>0 and remarks='OK' AND party='{party_name}' """,
            "number_of_loss_with_doubt": f"""{pu_query['query']}   select COALESCE(sum(case when row_num>1 AND total_valid_votes>0 and over_vote_values>0 then 1 else 0 end) ,0) as count1 FROM win_lga where 1=1 and party='{party_name}' """,
            "above_clearly_25": f"""{pu_query['query']}  select COUNT(*) AS count1 FROM lgat where 1=1 and remarks='OK' and {party_name}/total_vote_casted*100>=25 and state_name={state_name}  """,
            "above_with_doubt_25": f"""{pu_query['query']}  select COUNT(*) AS count1 FROM lgat where 1=1 and over_vote_values>0 and {party_name}/total_vote_casted*100>=25 and state_name={state_name}  """,


        },

        "tables": {

            "total": f"""{pu_query['query']}  select state_name,lga_name, Total_Registered_voters FROM lgat """,
            "total_collated": f"""{pu_query['query']}  select state_name,lga_name, {party_name} AS scores,total_vote_casted, remarks   FROM lgat where 1=1 and  status = 'collated' OR status='canceled' """,
            "total_non_collated": f"""{pu_query['query']}   select state_name,lga_name, Total_Registered_voters, remarks   FROM lgat where 1=1 and status='non collated'  """,
            "total_canceled": f"""{pu_query['query']}  select state_name,lga_name,Total_Registered_voters, remarks   FROM lgat where 1=1 and status = 'canceled'  """,
            "total_over_voting": f"""{pu_query['query']} select state_name,lga_name,  {party_name} AS scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, over_vote_values,remarks
  FROM lgat """,

            "number_clear_win": f"""{pu_query['query']}  select state_name,lga_name,  votes as scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, percentage_votes FROM win_lga 
where 1=1 and row_num<2 and total_valid_votes>0 and remarks='OK' AND party='{party_name}' """,

            "number_win_with_doubt": f"""{pu_query['query']}  select state_name,lga_name,  votes as scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters,over_vote_values, percentage_votes, remarks FROM win_lga 
where 1=1 and row_num<2 and total_valid_votes>0 and over_vote_values>0 AND party='{party_name}' """,

            "number_of_clear_loss": f"""{pu_query['query']}  select state_name,lga_name,  votes as scores, total_vote _casted,Total_Registered_voters,Total_Accredited_voters, percentage_votes FROM win_lga 
  where 1=1 and row_num>1 AND total_valid_votes>0 and remarks='OK' AND party='{party_name}' """,

            "number_of_loss_with_doubt": f"""{pu_query['query']}  select state_name,lga_name,  votes as scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, over_vote_values, percentage_votes, remarks FROM win_lga 
  where 1=1 and row_num>1 AND total_valid_votes>0 and over_vote_values>0 AND party='{party_name}' """,

            "above_clearly_25": f"""{pu_query['query']}  select state_name,lga_name,  {party_name} AS scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, CONCAT(ROUND({party_name}/total_vote_casted*100,2),'%') AS percentage_votes,remarks 
FROM lgat where 1=1 and remarks='OK' and {party_name}/total_vote_casted*100>=25 and state_name={state_name}  """,

            "above_with_doubt_25": f"""{pu_query['query']}  select state_name,lga_name,  {party_name} AS scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters,over_vote_values, CONCAT(ROUND({party_name}/total_vote_casted*100,2),'%') AS percentage_votes,remarks
FROM lgat where 1=1 and over_vote_values>0 and {party_name}/total_vote_casted*100>=25 and state_name={state_name}  """



        }
    },


        "state": {

            "values": {

                "total": f"""{pu_query['query']}  select  count(*) as count1 from st """,
                "total_collated": f"""{pu_query['query']}   select count(*) as collated from collated_st where 1=1 and deef=0  """,
                "total_non_collated": f"""{pu_query['query']}  select count(*)  from non_collated_st  where 1=1 and total=0   """,
                "total_canceled": f"""{pu_query['query']}  select count(*) as in_progress from collated_st where 1=1 and (deef>0 and deef<total)   """,
                "total_over_voting": f"""{pu_query['query']}  select count(*) as count1 from st where 1=1 and over_vote_values>0  """,
                "number_clear_win": f"""{pu_query['query']}   select count(*) as count1 from win_state where 1=1 and row_num<2 and total_valid_votes>0 and remarks='OK' AND party='{party_name}'   """,
                "number_win_with_doubt": f"""{pu_query['query']}  select count(*) as count1 from win_state where 1=1 and row_num<2 and total_valid_votes>0 and over_vote_values>0 AND party='{party_name}'   """,
                "number_of_clear_loss": f"""{pu_query['query']}  select count(*) as count1 from win_state where 1=1 and row_num>1 AND total_valid_votes>0 and remarks='OK' AND party='{party_name}'   """,
                "number_of_loss_with_doubt": f"""{pu_query['query']}   select COALESCE(sum(case when row_num>1 AND total_valid_votes>0 and over_vote_values>0 then 1 else 0 end) ,0) as count1 from win_state where 1=1 and party='{party_name}'   """,
                "above_clearly_25": f"""{pu_query['query']}  select COUNT(*) AS count1 from st where 1=1 and remarks='OK' and {party_name}/total_vote_casted*100>=25   """,
                "above_with_doubt_25": f"""{pu_query['query']}  select COUNT(*) AS count1 from lgat where 1=1 and over_vote_values>0 and {party_name}/total_vote_casted*100>=25 and state_name={state_name}  """,
                "general_party_performance": f"""{pu_query['query']}  
      	   
           select IFF (row_num<2 and total_valid_votes>0 and remarks='OK' AND party='{party_name}','clear leading',
 		IFF(row_num<2 and total_valid_votes>0 and over_vote_values>0 AND party='{party_name}','leading with doubt',
 			IFF( row_num>1  and total_valid_votes>0 and over_vote_values>0 AND party='{party_name}','lagging with doubt',
 			IFF(row_num>1 and total_valid_votes>0 and remarks='OK' AND party='{party_name}','clear lagging',''))) )
 			as current_update from win_country order by current_update desc limit 1 """

            },

            "tables": {

                "total": f"""{pu_query['query']}  select state_name,Total_Registered_voters from st  """,
                "total_collated": f"""{pu_query['query']}  select state_name,Total_Registered_voters from collated_state where 1=1 and deef=0  """,
                "total_non_collated": f"""{pu_query['query']}  select state_name,Total_Registered_voters  from non_collated_state  where 1=1 and total=0    """,
                "total_canceled": f"""{pu_query['query']}   select state_name,Total_Registered_voters from collated_state where 1=1 and (deef>0 and deef<total)   """,
                "total_over_voting": f"""{pu_query['query']} select state_name,  {party_name} AS scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, over_vote_values,remarks
  from st where 1=1  """,
                "number_clear_win": f"""{pu_query['query']}  select state_name,  votes as scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, percentage_votes from win_state 
where 1=1 and row_num<2 and total_valid_votes>0 and remarks='OK' AND party='{party_name}'   """,

                "number_win_with_doubt": f"""{pu_query['query']}  select state_name,  votes as scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters,over_vote_values, percentage_votes, remarks from win_state 
where 1=1 and row_num<2 and total_valid_votes>0 and over_vote_values>0 AND party='{party_name}'  """,

                "number_of_clear_loss": f"""{pu_query['query']}  select state_name,  votes as scores, total_vote _casted,Total_Registered_voters,Total_Accredited_voters, percentage_votes from win_state 
  where 1=1 and row_num>1 AND total_valid_votes>0 and remarks='OK' AND party='{party_name}'  """,

                "number_of_loss_with_doubt": f"""{pu_query['query']}  select state_name,  votes as scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, over_vote_values, percentage_votes, remarks from win_state 
  where 1=1 and row_num>1 AND total_valid_votes>0 and over_vote_values>0 AND party='{party_name}'  """,

                "above_clearly_25": f"""{pu_query['query']}  select state_name,  = AS scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters, CONCAT(ROUND('NNPP'/total_vote_casted*100,2),'%') AS percentage_votes,remarks 
from st where 1=1 and remarks='OK' and {party_name}/total_vote_casted*100>=25 and state_name={state_name}  """,

                "above_with_doubt_25": f"""{pu_query['query']}  select state_name,  F AS scores, total_vote_casted,Total_Registered_voters,Total_Accredited_voters,over_vote_values, CONCAT(ROUND({party_name}/total_vote_casted*100,2),'%') AS percentage_votes,remarks
from st where 1=1 and over_vote_values>0 and {party_name}/total_vote_casted*100>=25   """,

                "general_party_performance": f"""{pu_query['query']}  
    	 select ROW_NUMBER() OVER(PARTITION BY country_name ORDER BY votes DESC) AS row_num,party,votes as Scores,		
       IFF (total_vote_casted>0, concat(round(votes/total_vote_casted*100,2),'%'),'Collation has not started') as percentage_score FROM win_country 
          """

            }
        }
    }


